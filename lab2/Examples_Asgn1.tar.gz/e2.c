void main()
{
	int Main;
	int *p;
	p=&Main;
	*p = 5;
}
