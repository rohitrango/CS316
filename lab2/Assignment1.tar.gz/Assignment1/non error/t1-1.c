void main()

{
	int a, b, c;
	int *p, *q, *r; 

	p = &a;
        q = &b;
        r = &c;

        
}
