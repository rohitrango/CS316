void main()
{
	int harsh_maheshwari;
	int *akshay;
	akshay = &harsh_maheshwari;
	*akshay = 768;
}
