void main()
{
	int a;
	pa = &a;
	*pa = 5;
}
