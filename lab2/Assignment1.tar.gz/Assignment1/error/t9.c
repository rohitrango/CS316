void main()
{
	int a;
	int *p = 5;
}
