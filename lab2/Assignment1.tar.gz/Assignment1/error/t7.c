void Main()
{
	int a;
	int *p;
}
