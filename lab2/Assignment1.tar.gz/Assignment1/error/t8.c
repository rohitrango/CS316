void main()
{
	int a;
	int *p;
	p = &a;
	*p = "jdkslajd";
}
