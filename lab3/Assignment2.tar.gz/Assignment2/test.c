void main()
{
	int a, b, c;
	int *p, **q, d;
	**b = *b * *c + 3;
	b = *&d;
	*p = a - b * *d / l + 2;
	*p = -a;
}
