void main()
{
	int i1, i2;

	*i1 = -*i1-*i2;
}
