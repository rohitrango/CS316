void main()
{
	int a;

	a=p;
	*b=*a+*b;
	*a=*b-*a;
	*a = 5 + -4 *m;
	a = *b - 3 / a * &h;
	*&&&a = 5;
}
