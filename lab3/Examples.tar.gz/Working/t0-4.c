void main()
{
	int a;
	int f;

	*&&&a = *&a + *f - &g;
}
