void main()
{
	int a, *pa, b;
	int ***b;
	b = &a;
	*b = (&a);
	****ca = &(a);	
}
