void main(int a)
{
	a = 3;
	main(a+1);
}
