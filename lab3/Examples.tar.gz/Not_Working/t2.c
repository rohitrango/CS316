void main()
{
	int a;
	int b;
	int *pa, c, **d0;
	pa = 2 / a + b - -c * d0;
	&pa = a;
}
